import logging
from responses import activate as mock_responses
from nose import with_setup
from nose.tools import assert_raises
import enmscripting
from enmscripting.private.session import (ExternalSession, _AUTH_COOKIE_KEY, LoginResponseParser)
from .session_mock_utils import *

logging.basicConfig()
logging.getLogger().setLevel(level=logging.DEBUG)


@mock_responses
@with_setup(setup_session_mock, teardown_session_mock)
def test_open():
    mock_login_response('testCookie', '0')
    session = enmscripting.open(login_url, 'username', 'pass')._session

    assert session
    assert isinstance(session, ExternalSession)


@mock_responses
@with_setup(setup_session_mock, teardown_session_mock)
def test_open_authentication_failed_auth_code_not_0():
    mock_login_response('testCookie', '-1')
    assert_raises(ValueError, enmscripting.open, login_url, 'username', 'pass')


@mock_responses
@with_setup(setup_session_mock, teardown_session_mock)
def test_open_authentication_failed_auth_code_minus_2():
    mock_login_response('testCookie', '-2')
    assert_raises(ValueError, enmscripting.open, login_url, 'username', 'pass')


@mock_responses
@with_setup(setup_session_mock, teardown_session_mock)
def test_open_no_cookie():
    mock_login_response(None, '0')
    assert_raises(ValueError, enmscripting.open, login_url, 'username', 'pass')


@mock_responses
@with_setup(setup_session_mock, teardown_session_mock)
def test_open_authentication_failed_no_auth_code():
    mock_login_response('testCookie', None)
    assert_raises(ValueError, enmscripting.open, login_url, 'username', 'pass')


@mock_responses
@with_setup(setup_session_mock, teardown_session_mock)
def test_close():

    mock_login_response()
    enm_session = enmscripting.open(login_url, 'username', 'pass')

    session = enm_session._session
    assert len(session.cookies) is 1

    mock_logout_response()
    enmscripting.close(enm_session)
    assert len(session.cookies) is 0


@mock_responses
@with_setup(setup_session_mock, teardown_session_mock)
def test_open_password_reset_required():
    mock_login_response('testCookie', None, '<html><head id="oasis_login">'
                                            '<script language="JavaScript" type="text/javascript">'
                                            '<!-- function redirectToEnmPasswordChange() {} --></script>'
                                            '</head><body id="null" onload="redirectToEnmPasswordChange()" /></html>')
    try:
        enmscripting.open(login_url, 'username', 'pass')
        assert False, 'Open should throw ValueError, when user is required to change password'
    except ValueError as e:
        assert 'password change required' in str(e), 'Incorrect error message [%s]' % str(e)


def test_login_response_redirect_true():
    assert LoginResponseParser('<html><body id="null" onload="redirectToEnmPasswordChange()" /><some></some>'
                               '</html>').password_change_redirect() is True


def test_login_response_redirect_false():
    assert LoginResponseParser('<html><body id="null" onload="someMethod()">redirectToEnmPasswordChange</body>'
                               '</html>').password_change_redirect() is False
