from nose.tools import assert_raises
from enmscripting.command.command import *
from .json_generator import *
import logging

logging.basicConfig()
logging.getLogger().setLevel(level=logging.DEBUG)


def test_create_command_output_with_command():
    json = generate_json(0, 0, 0, 0, 0)
    result = CommandOutput(json, 200, True)
    assert result._command == COMMAND


def test_command_output_error_status():
    json = generate_json(0, 0, 0, 0, 0)
    result = CommandOutput(json, 200, False)
    assert_raises(IllegalStateException, result.get_output)
