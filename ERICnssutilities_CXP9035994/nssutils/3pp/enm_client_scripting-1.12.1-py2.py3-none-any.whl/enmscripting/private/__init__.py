"""
enm-client-scripting private modules and classes.

This is a private module and should not be imported outside of the client-scripting module.
"""
