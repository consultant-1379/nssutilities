from .terminal.terminal import EnmTerminal
from .command.command import EnmCommand


class EnmSession():
    """
    This class holds a session to a running ENM deployment
    """
    def __init__(self, session=None):
        self._session = session

    def terminal(self):
        """
        Returns an instance of EnmTerminal
        """
        return EnmTerminal(self._session)

    def command(self):
        """
        Returns an instance of EnmCommand
        """
        return EnmCommand(self._session)
